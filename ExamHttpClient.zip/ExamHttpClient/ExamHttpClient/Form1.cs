﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Http;
using System.IO;
using System.Threading;
namespace ExamHttpClient
{
    public partial class Form1 : Form
    {
        static ManualResetEvent manualReset = new ManualResetEvent(true);
        static bool Cancel = false;
        public Form1()
        {
            InitializeComponent();
            textBox1.Enabled = true;
        }
        public async void butoon_click(object sender,EventArgs e)
        {
            var FileName= textBox1.Text.Substring(textBox1.Text.LastIndexOf("/")+1);
            if (FileName.Trim() == "")
            {
                MessageBox.Show("This url wrong");
                return;
            }
            
            await GetFile(textBox1.Text, FileName);
        }
        public async Task GetFile(string url,string filename)
        {
            
            Stream stream;
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.FileName = filename;
            
            if(saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                if(( stream = saveFileDialog.OpenFile())!= null)
                {
                    MessageBox.Show(saveFileDialog.FileName);
                    HttpClient httpClient = new HttpClient();
                    var file = await httpClient.GetStreamAsync(url);
                    var lenght = GetFileSize(url);
                    progressBar1.Minimum = 0;
                    progressBar1.Maximum = Convert.ToInt32(lenght  / 2048);
                    if(lenght % 2048 != 0)
                    {
                        progressBar1.Maximum += 1;
                    }
                     Task.Run(() => ReadAndWriteFile(stream, file,saveFileDialog.FileName));
                   
                }
                
            }
            
        }
        public long GetFileSize(string url)
        {
            long result = -1;
            System.Net.WebRequest req = System.Net.WebRequest.Create(url);
            req.Method = "HEAD";
            using (System.Net.WebResponse resp = req.GetResponse())
            {
                if (long.TryParse(resp.Headers.Get("Content-Length"), out long ContentLength))
                {
                    result = ContentLength;
                }
            }
            return result;
        }
        async Task ReadAndWriteFile(Stream input, Stream mygetfileStream,string filename)
        {
            using (mygetfileStream)
            {
                using (input)
                {
                    byte[] buffer = new byte[2048];
                    int count;
                    while ((count = await mygetfileStream.ReadAsync(buffer, 0, buffer.Length)) > 0&&!Cancel)
                    {
                        await input.WriteAsync(buffer, 0, count);
                        manualReset.WaitOne();
                        progressBar1.Value++;
          
                    }
                    if (Cancel)
                    {
                        progressBar1.Value = 0;
                        File.Delete(filename);
                    }
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            manualReset.Reset();
            button3.Enabled = true;
            button2.Enabled = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            manualReset.Set();
            button3.Enabled = false;
            button2.Enabled = true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Cancel = true;
        }
    }
}
